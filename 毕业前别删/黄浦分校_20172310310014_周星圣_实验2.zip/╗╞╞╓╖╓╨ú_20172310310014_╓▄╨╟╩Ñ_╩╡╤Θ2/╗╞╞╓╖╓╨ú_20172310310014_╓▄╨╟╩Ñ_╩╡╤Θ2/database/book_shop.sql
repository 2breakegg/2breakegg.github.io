/*
Navicat MySQL Data Transfer

Source Server         : break_copy
Source Server Version : 50719
Source Host           : 192.168.0.57:3306
Source Database       : bookshop

Target Server Type    : MYSQL
Target Server Version : 50719
File Encoding         : 65001

Date: 2018-11-28 22:57:46
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `t_admin`
-- ----------------------------
DROP TABLE IF EXISTS `t_admin`;
CREATE TABLE `t_admin` (
  `userId` int(11) NOT NULL,
  `userName` varchar(55) DEFAULT NULL,
  `userPw` longtext,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_admin
-- ----------------------------
INSERT INTO `t_admin` VALUES ('1', 'a', 'a');

-- ----------------------------
-- Table structure for `t_catelog`
-- ----------------------------
DROP TABLE IF EXISTS `t_catelog`;
CREATE TABLE `t_catelog` (
  `catelog_id` int(11) NOT NULL,
  `catelog_name` varchar(55) DEFAULT NULL,
  `catelog_miaoshu` longtext,
  `catelog_del` longtext,
  PRIMARY KEY (`catelog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_catelog
-- ----------------------------
INSERT INTO `t_catelog` VALUES ('10', '程序', '程序', 'no');
INSERT INTO `t_catelog` VALUES ('11', '小说', '小说', 'no');
INSERT INTO `t_catelog` VALUES ('12', '心理', '心理', 'no');
INSERT INTO `t_catelog` VALUES ('13', '经济', '经济', 'no');
INSERT INTO `t_catelog` VALUES ('14', '历史', '历史', 'no');

-- ----------------------------
-- Table structure for `t_gonggao`
-- ----------------------------
DROP TABLE IF EXISTS `t_gonggao`;
CREATE TABLE `t_gonggao` (
  `gonggao_id` int(11) NOT NULL,
  `gonggao_title` varchar(55) DEFAULT NULL,
  `gonggao_content` longtext,
  `gonggao_data` varchar(50) DEFAULT NULL,
  `gonggao_fabuzhe` tinytext,
  `gonggao_del` varchar(50) DEFAULT NULL,
  `gonggao_one1` varchar(50) DEFAULT NULL,
  `gonggao_one2` varchar(50) DEFAULT NULL,
  `gonggao_one3` varchar(50) DEFAULT NULL,
  `gonggao_one4` varchar(50) DEFAULT NULL,
  `gonggao_one5` datetime DEFAULT NULL,
  `gonggao_one6` datetime DEFAULT NULL,
  `gonggao_one7` int(11) DEFAULT NULL,
  `gonggao_one8` int(11) DEFAULT NULL,
  PRIMARY KEY (`gonggao_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_gonggao
-- ----------------------------
INSERT INTO `t_gonggao` VALUES ('1', '对于本欢迎大家提出宝贵意见', '<strong>对于本欢迎大家提出宝贵意见</strong>', '2013-03-31 0:37:30', null, null, null, null, null, null, null, null, null, null);
INSERT INTO `t_gonggao` VALUES ('2', '部分商品8折销售。欢迎选购', '<strong>部分商品8折销售。欢迎选购</strong>', '2013-03-31 0:37:30', null, null, null, null, null, null, null, null, null, null);
INSERT INTO `t_gonggao` VALUES ('3', '测试公告测试公告测试公告', '测试公告测试公告测试公告', '2013-03-31 0:37:30', null, null, null, null, null, null, null, null, null, null);

-- ----------------------------
-- Table structure for `t_goods`
-- ----------------------------
DROP TABLE IF EXISTS `t_goods`;
CREATE TABLE `t_goods` (
  `goods_id` int(11) NOT NULL,
  `goods_name` varchar(55) DEFAULT NULL,
  `goods_miaoshu` longtext,
  `goods_pic` varchar(50) DEFAULT NULL,
  `goods_yanse` varchar(50) DEFAULT NULL,
  `goods_shichangjia` int(11) DEFAULT NULL,
  `goods_tejia` int(11) DEFAULT NULL,
  `goods_isnottejia` varchar(50) DEFAULT NULL,
  `goods_isnottuijian` varchar(50) DEFAULT NULL,
  `goods_catelog_id` int(11) DEFAULT NULL,
  `goods_kucun` int(11) DEFAULT NULL,
  `goods_Del` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`goods_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_goods
-- ----------------------------
INSERT INTO `t_goods` VALUES ('0', '月亮和六便士', null, null, null, null, null, null, null, null, null, null);
INSERT INTO `t_goods` VALUES ('13', 'Head First设计模式', '本书共有14章，每章都介绍了几个设计模式，完整地涵盖了四人组版本全部23个设计模式。', '/upload/h1.jpg', null, '67', '67', 'no', null, '10', '-4', 'no');
INSERT INTO `t_goods` VALUES ('14', '算法导论', '该书是一本十分经典的计算机算法书籍，与高德纳（Donald E.Knuth）的《计算机程序设计艺术》（The Art Of Computer Programming）相媲美。 《算法导论》由Thomas H.Cormen、Charles E.Leiserson、Ronald L.Rivest、Clifford Stein四人合作编著（其中Clifford Stein是第二版开始参与的合著者）。本书的最大特点就是将严谨性和全面性融入在了一起。', '/upload/h2.jpg', null, '94', '94', 'no', null, '10', '0', 'no');
INSERT INTO `t_goods` VALUES ('15', 'OpenGL编程指南', '《华章程序员书库：OpenGL编程指南（原书第8版）》是由Khronos小组编写的官方指南，是OpenGL领域的专业著作，素有“OpenGL”的美誉。第8版针对OpenGL4．3版本全方位阐释OpenGL的各种技术细节、方法和佳实践，帮助程序员走上OpenGL专家之路。', '/upload/h3.jpg', null, '106', '106', 'no', null, '10', '0', 'no');
INSERT INTO `t_goods` VALUES ('16', 'C#高级编程(第9版)', '本书由.NET专家的梦幻组合编写，包含开发人员使用C#所需的所有内容。C#是编写.NET应用程序的一种语言，本书适合于希望提高编程技巧的、有经验的C#程序员，也适用于刚开始使用C#的专业开发人员。本书探讨了Visual Studio 2013和.NET Framework4.5.1、新的测试驱动开发和并发编程功能。所有示例的源代码都可以下载，读者可以立即开始编写Windows桌面应用程序、Windows Store应用程序和ASP.NET Web应用程序。', '/upload/h4.jpg', null, '85', '85', 'no', null, '10', '-1', 'no');
INSERT INTO `t_goods` VALUES ('17', '1984', '《1984》是一部杰出的政治寓言小说，也是一部幻想小说。作品刻画了人类在极权主义社会的生存状态，有若一个永不褪色的警示标签，警醒世人提防这种预想中的黑暗成为现实。历经几十年，其生命力益显强大，被誉为20世纪影响最为深远的文学经典之一。', '/upload/xs1.jpg', '', '19', '19', 'no', '', '11', '0', 'no');
INSERT INTO `t_goods` VALUES ('18', '偏执狂', '　　纵观人类的整个战争史，可以明显看到偏执与妄想狂的幽灵显现。这些偏执狂手握阴谋论的大棒，简单粗暴，却又注定会受到大众的追捧。这样一种简单、有效的观念，把新生的反抗力量毒杀在摇篮中。相反，民主与和平的再生，需要承诺、牺牲和理性——这些心智过程却又无法如此迅速地激发或感染群众。无处不在的偏执狂，制造了人类一场场的浩劫。\r\n　　在《偏执狂：“疯子”创造历史》一书中，心理分析家鲁格•肇嘉将荣格分析心理学的原型理论作为剖析偏执狂的方法与应用。作者从神话入手，通过古典时代（埃阿斯）与两次世界大战（希特勒和斯大林）中的偏执狂意象，去探索种族灭绝过程及种族灭绝心理的现实意义。作者还进一步指出，轻度的偏执与妄想，是日常生活中的常见之物。书中没有把偏执与妄想视为一种疾病，而是视为一种普遍存在于人群之中的可能性。但是，这个心理特性或许也能够出现在任何日子里、任何人身上。它是我们内心的小“希特勒”。\r\n', '/upload/xl2.jpg', '', '69', '69', 'no', '', '12', '-14', 'no');
INSERT INTO `t_goods` VALUES ('19', '国富论', '亚当斯密的《国富论》，原名直译为《诸国民之富的性质及其原因之研究》。自一七七六年出版以来，全世界的学术界，都曾赫然为所惊动。甚至于各国的支配者们，都相率奉之为圭臬。世界上每个大的或小的经济学家，都曾直挡或间接受其影响。对之推崇到无可进一步推崇，甚至于自命为斯密信徒的人们，亦会从中取出几个章句来批评；反之，对之批评到无可进一步批评，甚至于公然反对斯密主义的人们，亦莫不从中采纳几种意见，作为自己的根本思想。', '/upload/jj1.jpg', null, '24', '24', 'no', null, '13', '0', 'no');
INSERT INTO `t_goods` VALUES ('21', '人类简史', '这是关于我们人类祖先的故事！很久很久以前，人们相信地球像一块大饼，而天空像顶盖子一样罩在上方；后来，工具、技术、宗教、艺术一一被创造出来。我们的祖先也已在地球上演化了数百万年，留下了讲不完的故事。', '/upload/ls1.jpg', null, '112', '112', 'no', null, '14', '-5', 'no');
INSERT INTO `t_goods` VALUES ('22', '梦的解析 精神分析引论', '通过对梦的剖析，提出“潜意识”与“俄狄浦斯情结”等重要概念，标志着精神分析体系的正式建立。深刻影响了人类看待自我和世界的方式，与《天体运行论》《物种起源》并称思想史上三大里程碑。无法回避的基石巨著。', '/upload/xl1.jpg', null, '69', '69', 'no', null, '12', '-13', 'no');
INSERT INTO `t_goods` VALUES ('23', '三体（套装1-3册）', '《三体》为“中国科幻基石丛书”之一。小说主要讲述了在文化大革命如火如荼进行的同时，军方探寻外星文明的绝秘计划“红岸工程”取得了突破性进展。但在按下发射键的那一刻，历经劫难且对人类充满愤恨的叶文洁没有意识到，她彻底改变了人类的命运。地球文明向宇宙发出的一声啼鸣，以太阳为中心，以光速向宇宙深处飞驰……\r\n　　《三体》三部曲（又名“地球往事“三部曲）由《三体》、《黑暗森林》、《死神永生》三部小说组成。\r\n　　《三体》三部曲被誉为迄今为止中国当代杰出的科幻小说，是中国科幻文学的里程碑之作，将中国科幻推上了世界的高度，曾获得美国科幻奇幻协会“星云奖”提名。2015年8月23日，《三体》获第73届雨果奖长篇故事奖，这是亚洲人首次获得雨果奖。\r\n', '/upload/xs3.jpg', '', '83', '83', 'no', '', '11', '0', 'no');
INSERT INTO `t_goods` VALUES ('24', '月亮和六便士', '书中的主人公“我”是伦敦怀才不遇的作家，偶然间认识了一位证券经纪人，对方在人届中年后突然响应内心的呼唤，离经叛道舍弃一切，先是奔赴巴黎，后又到南太平洋的塔希提岛与土著人一起生活，全身心投入绘画，并在死后声名大噪。“我”在他成名后开始追溯与艺术家曾经的来往与对方之后的人生经历。\r\n书中的主人公“我”是伦敦怀才不遇的作家，偶然间认识了一位证券经纪人，对方在人届中年后突然响应内心的呼唤，离经叛道舍弃一切，先是奔赴巴黎，后又到南太平洋的塔希提岛与土著人一起生活，全身心投入绘画，并在死后声名大噪。“我”在他成名后开始追溯与艺术家曾经的来往与对方之后的人生经历。\r\n\r\n书中的主人公“我”是伦敦怀才不遇的作家，偶然间认识了一位证券经纪人，对方在人届中年后突然响应内心的呼唤，离经叛道舍弃一切，先是奔赴巴黎，后又到南太平洋的塔希提岛与土著人一起生活，全身心投入绘画，并在死后声名大噪。“我”在他成名后开始追溯与艺术家曾经的来往与对方之后的人生经历。\r\n', '/upload/xs2.jpg', '', '34', '34', 'no', '', '11', '-1', 'no');

-- ----------------------------
-- Table structure for `t_liuyan`
-- ----------------------------
DROP TABLE IF EXISTS `t_liuyan`;
CREATE TABLE `t_liuyan` (
  `liuyan_id` int(11) NOT NULL,
  `liuyan_title` varchar(55) DEFAULT NULL,
  `liuyan_content` longtext,
  `liuyan_date` longtext,
  `liuyan_user` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`liuyan_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_liuyan
-- ----------------------------
INSERT INTO `t_liuyan` VALUES ('1', 'just a test', '<p>log test</p>', '2018-11-4 12:41:28', 'zhouxingsheng20172310310014');

-- ----------------------------
-- Table structure for `t_order`
-- ----------------------------
DROP TABLE IF EXISTS `t_order`;
CREATE TABLE `t_order` (
  `order_id` int(11) NOT NULL,
  `order_bianhao` varchar(55) DEFAULT NULL,
  `order_date` varchar(50) DEFAULT NULL,
  `order_zhuangtai` varchar(50) DEFAULT NULL,
  `order_songhuodizhi` varchar(50) DEFAULT NULL,
  `order_fukuangfangshi` varchar(50) DEFAULT NULL,
  `order_jine` int(11) DEFAULT NULL,
  `order_user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_order
-- ----------------------------
INSERT INTO `t_order` VALUES ('6', '20181027011316', '2018-10-27 01:13:16', 'yes', '', '????', '629', '1');
INSERT INTO `t_order` VALUES ('7', '20181027025152', '2018-10-27 02:51:52', 'no', '', '????', '112', '2');
INSERT INTO `t_order` VALUES ('8', '20181104105606', '2018-11-04 10:56:06', 'no', '', '????', '327', '2');
INSERT INTO `t_order` VALUES ('10', '20181104123556', '2018-11-04 12:35:56', 'no', '??????...', '????', '134', '4');

-- ----------------------------
-- Table structure for `t_orderitem`
-- ----------------------------
DROP TABLE IF EXISTS `t_orderitem`;
CREATE TABLE `t_orderitem` (
  `orderItem_id` int(11) NOT NULL,
  `order_id` int(11) DEFAULT NULL,
  `goods_id` int(11) DEFAULT NULL,
  `goods_quantity` int(11) DEFAULT NULL,
  PRIMARY KEY (`orderItem_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_orderitem
-- ----------------------------
INSERT INTO `t_orderitem` VALUES ('5', '2', '24', '1');
INSERT INTO `t_orderitem` VALUES ('6', '3', '16', '1');
INSERT INTO `t_orderitem` VALUES ('7', '3', '21', '1');
INSERT INTO `t_orderitem` VALUES ('8', '4', '18', '2');
INSERT INTO `t_orderitem` VALUES ('9', '5', '23', '1');
INSERT INTO `t_orderitem` VALUES ('10', '6', '18', '11');
INSERT INTO `t_orderitem` VALUES ('11', '6', '24', '2');
INSERT INTO `t_orderitem` VALUES ('12', '7', '21', '1');
INSERT INTO `t_orderitem` VALUES ('13', '8', '18', '1');
INSERT INTO `t_orderitem` VALUES ('14', '8', '21', '2');
INSERT INTO `t_orderitem` VALUES ('15', '8', '24', '1');
INSERT INTO `t_orderitem` VALUES ('16', '10', '13', '2');

-- ----------------------------
-- Table structure for `t_user`
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(55) DEFAULT NULL,
  `user_pw` varchar(50) DEFAULT NULL,
  `user_type` int(11) DEFAULT NULL,
  `user_realname` varchar(50) DEFAULT NULL,
  `user_address` varchar(50) DEFAULT NULL,
  `user_sex` varchar(50) DEFAULT NULL,
  `user_tel` varchar(50) DEFAULT NULL,
  `user_email` varchar(50) DEFAULT NULL,
  `user_qq` varchar(50) DEFAULT NULL,
  `user_man` varchar(50) DEFAULT NULL,
  `user_age` varchar(50) DEFAULT NULL,
  `user_birthday` varchar(50) DEFAULT NULL,
  `user_xueli` varchar(50) DEFAULT NULL,
  `user_del` varchar(50) DEFAULT NULL,
  `user_one1` varchar(50) DEFAULT NULL,
  `user_one2` varchar(50) DEFAULT NULL,
  `user_one3` varchar(50) DEFAULT NULL,
  `user_one4` varchar(50) DEFAULT NULL,
  `user_one5` varchar(50) DEFAULT NULL,
  `user_one6` int(11) DEFAULT NULL,
  `user_one7` int(11) DEFAULT NULL,
  `user_one8` int(11) DEFAULT NULL,
  `user_one9` datetime DEFAULT NULL,
  `user_one10` datetime DEFAULT NULL,
  `user_one11` decimal(19,0) DEFAULT NULL,
  `user_one12` decimal(19,0) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('2', 'user', '111111', '0', 'zhouxingsheng', '中国上海', '男', '13622222222', 'aaa@qq.com', '111111111', null, null, null, null, 'no', null, null, null, null, null, null, null, null, null, null, null, null);
