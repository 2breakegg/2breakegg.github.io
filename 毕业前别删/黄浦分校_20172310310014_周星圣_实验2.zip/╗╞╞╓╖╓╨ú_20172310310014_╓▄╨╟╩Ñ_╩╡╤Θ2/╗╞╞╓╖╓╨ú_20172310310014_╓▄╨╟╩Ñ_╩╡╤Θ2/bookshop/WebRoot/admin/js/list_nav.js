var t;
t=outlookbar.addtitle('系统属性')
outlookbar.additem('系统属性',t,'/bookshop/admin/index/sysPro.jsp')


t=outlookbar.addtitle('修改密码')
outlookbar.additem('修改密码',t,'/bookshop/admin/userinfo/userPw.jsp')


t=outlookbar.addtitle('用户管理')
outlookbar.additem('用户管理',t,'/bookshop/userMana.action')

t=outlookbar.addtitle('商品类别')
outlookbar.additem('类别管理',t,'/bookshop/catelogMana.action')
outlookbar.additem('添加类别',t,'/bookshop/admin/catelog/catelogAdd.jsp')

t=outlookbar.addtitle('商品管理')
outlookbar.additem('商品管理',t,'/bookshop/goodsManaNoTejia.action')
outlookbar.additem('添加商品',t,'/bookshop/admin/goods/goodsNoTejiaAdd.jsp')


t=outlookbar.addtitle('订单管理')
outlookbar.additem('订单管理',t,'/bookshop/orderMana.action')

t=outlookbar.addtitle('网站论坛')
outlookbar.additem('网站论坛',t,'/bookshop/liuyanMana.action')


t=outlookbar.addtitle('退出系统') 
outlookbar.additem('安全退出',t,'/bookshop/login.jsp')